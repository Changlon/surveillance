 
module.exports = {  
    PORT:3000 ,
    domain: 'http://127.0.0.1' ,
    notifyPath: '/notify'
}
 