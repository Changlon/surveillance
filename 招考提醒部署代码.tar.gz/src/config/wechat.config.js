
//测试环境
// module.exports = {
//     appId:"wx3ace0c0fa2f4cab0",
//     appSecret:"8ea32e13460637765fb65a5e48b7c023",
//     token:"changlon"
// }



//生产环境
module.exports = {
    appId:"wx9cc410b883c7c06c",
    appSecret:"ca3b070151d87a1e43e82363af96141e",
    token:"changlon",
    encodingAESKey:"lelZ1jzT337TAAFjLC6mjbvfwmHRnqrUNiSj0yXD9bn"
}







