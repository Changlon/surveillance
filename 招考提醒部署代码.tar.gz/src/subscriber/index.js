
const koa = require('koa')
const koaRouter = require('koa-router')
const koaXmlBody = require('koa-xml-body')
const koaBodyParser = require('koa-bodyparser')
const koaWechat = require('koa-wechat-public') 
const f2json = require('f2json')()
const wechatConfig = require('../config/wechat.config') 
const { PORT,notifyPath} = require('../config/server.config')

const app = new koa()
const router = new koaRouter()  

const weapp = new koaWechat({
    appId:wechatConfig.appId,
    appSecret:wechatConfig.appSecret,
    token:wechatConfig.token,
    encodingAESKey:wechatConfig.encodingAESKey 
})


weapp
.text(/.+/,async acc =>{
    console.log(`接受消息:${acc.fromUser}`)
    acc.send.sendTxtMsg(acc.content) 
})  
.subscribe(async acc =>{ 
    console.log(`接受关注:${acc.fromUser}`)
})

router.all("/wechat",weapp.start())  

router.all(notifyPath, async (ctx,next)=>{ 
    console.log(`notify`)
    const body = ctx.request.body
    //通知公众号推送消息 
    const name =   body.name  
    const content =  body.content
    const url =  body.url
    const update = body.update
    console.log(ctx.request.body)
    const {json} =  f2json.file2json("../../vip.json")  
    const resData = []
    for(let openid of json) {
        
         const res = await weapp.pushTemplateMsg(openid,"5GGn3qdu3j3lkH-114DAW0jzorTB1qt3Al8wN2KmdX0",{  
                
                first:{
                    value:"招考更新通知",
                    color:"#FF3030"
                },
                keyword1:{ 
                    value:name,
                    color:"#FF3030"
                },
                keyword2:{
                    value:"昆仑堂堂主",
                    color:"#FF3030"
                },
                keyword3:{
                    value:update,
                    color:"#FF3030"
                },
                keyword4:{
                    value:content,
                    color:"#FF3030"
                },
                remark:{
                    value:"" 
                }
            
        },url)
        
        resData.push(res)
        
    }
  
    ctx.body = {
        notify:json,
        resData
    }

})

app.use(koaXmlBody())
app.use(koaBodyParser())
app.use(router.routes())
app.listen(PORT,()=>{
    console.log(`success! application is running on port : ${PORT}`)
}) 
