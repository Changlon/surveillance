
const Crawler = require('crawler')
const c = new Crawler()
c.queue(`https://www.ganseea.cn/html/tzgg/`)  

